import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SITE_URL = "https://tablasdemultiplicar.app";
const today = new Date().toISOString().slice(0, 10);
const articlesDir = path.join(__dirname, "../src/content/articles");

const escape = (str) => str
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&apos;");

const staticPaths = [
  "/",
  "/articulos",
  "/todas-las-tablas-de-multiplicar",
  "/juegos-tablas-de-multiplicar",
  "/ejercicios-tablas-de-multiplicar",
  "/tablas-de-multiplicar-para-imprimir",
  "/tabla-pitagorica",
  "/contrarreloj",
  "/prueba-tablas-de-multiplicar",
  "/diploma-tablas-de-multiplicar",
  "/aprender-tablas-de-multiplicar",
  "/trucos-tablas-de-multiplicar",
  "/metodologia",
  "/para-profesores",
  "/para-padres",
  "/practicar-errores",
  "/juego-memoria-multiplicaciones",
  "/sobre-nosotros",
];

const articles = fs.readdirSync(articlesDir)
  .filter((file) => file.endsWith(".js") && file !== "index.js")
  .map((file) => fs.readFileSync(path.join(articlesDir, file), "utf8"))
  .map((source) => {
    const slug = source.match(/slug:\s*["']([^"']+)["']/)?.[1];
    const updatedAt = source.match(/updatedAt:\s*["'](\d{4}-\d{2}-\d{2})["']/)?.[1];
    const date = source.match(/date:\s*["'](\d{4}-\d{2}-\d{2})["']/)?.[1];
    return slug ? { slug, lastmod: updatedAt || date || today } : null;
  })
  .filter(Boolean);

const urls = [
  ...staticPaths.map((p) => ({ loc: `${SITE_URL}${p}`, lastmod: today })),
  ...Array.from({ length: 12 }, (_, i) => ({ loc: `${SITE_URL}/tabla-del-${i + 1}`, lastmod: today })),
  ...articles.map((article) => ({ loc: `${SITE_URL}/articulos/${article.slug}`, lastmod: article.lastmod })),
];

const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map((u) => `  <url>\n    <loc>${escape(u.loc)}</loc>\n    <lastmod>${u.lastmod}</lastmod>\n  </url>`).join("\n")}\n</urlset>\n`;

fs.writeFileSync(path.join(__dirname, "../public/sitemap.xml"), xml, "utf8");
console.log(`✅ sitemap.xml generado correctamente (${urls.length} URLs)`);
